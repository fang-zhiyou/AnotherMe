import torch
from torch import nn
from torch.nn import functional as F


class TSHN(nn.Module):
    """
    神经网络结构
    """
    def __init__(self):
        super(TSHN, self).__init__()
        # 1. 对5D矩阵的卷积处理和打平部分
        self.conv1 = nn.Sequential(     # (5, 256, 256)
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 128, 128)  params: in_channels, out_channels, kernel_size, stride, padding
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 64, 64)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 32, 32)
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 16, 16)
        )
        self.fc1 = nn.Linear(5 * 16 * 16, 512)
        self.fc2 = nn.Linear(512, 128)

        # 2. 对5维向量的全连接层部分
        self.fc3 = nn.Linear(4, 16)
        self.fc4 = nn.Linear(16, 4)

        # 3. 1和2的结果向量合并部分
        self.combine = nn.Linear(132, 32)  # 128 + 4
        self.fc5 = nn.Linear(32, 1)

    def forward(self, x, y):
        #print(x)
        #print(y.shape)
        # 1. 对5D矩阵的卷积处理和打平部分
        x = self.conv1(x)
        x = self.conv2(x)
        x = x.view(x.size(0), -1)
        # x = F.dropout(x, p=0.5)
        x = self.fc1(x)
        x = F.relu(x)
        x = F.dropout(x, p=0.5)
        x = self.fc2(x)
        x = F.relu(x)
        #print(x)

        # 2. 对5维向量的全连接层部分
        y = self.fc3(y)
        y = F.relu(y)
        #print(x)
        y = self.fc4(y)
        y = F.relu(y)

        # 3. 1和2的结果向量合并部分
        xy = torch.cat((x, y), dim=1)
        xy = self.combine(xy)
        xy = F.relu(xy)
        # xy = F.dropout(xy, p=0.5)
        output = self.fc5(xy)
        return output.squeeze(-1)
