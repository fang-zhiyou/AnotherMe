import math
import os
from Utiliy import CoordSysConv


def ParseTime(time_str):
    """
    把"hh:mm:ss"格式的时间转换为秒数
    :param time_str: 字符串格式的时间
    :return: 转换成的秒数
    """
    time_list = time_str.split(':')
    seconds = int(time_list[0]) * 3600 + int(time_list[1]) * 60 + int(time_list[2])
    return seconds


def VectorUnitize(vector):
    """
    向量单位化
    :param vector: 含2个元素的向量(x, y)
    :return: 单位化的向量
    """
    length = math.sqrt(vector[0] ** 2 + vector[1] ** 2)

    if length == 0:
        return 0, 0
    else:
        return vector[0] / length, vector[1] / length


def CalAverage(data_list):
    """
    计算一个方向向量列表的平均值
    :param data_list: 目标列表
    :return: 平均方向（x,y组成的向量）
    """
    length = len(data_list)
    if length == 0:  # 空列表的平均数按(0,0)计算
        return 0, 0
    x, y = 0, 0
    for item in data_list:
        x += item[0]
        y += item[1]
    x /= length
    y /= length
    return x, y


def CalMedian(data_list):
    """
    计算一个列表的中位数
    :param data_list: 目标列表
    :return: 目标列表的中位数
    """
    length = len(data_list)
    if length == 0:  # 空列表中位数按0计算
        return 0
    data_list = sorted(data_list)
    if len(data_list) % 2 == 0:  # 偶数
        return 0.5 * (data_list[length // 2] + data_list[length // 2 - 1])
    else:
        return data_list[length // 2]


def VecToAngle(dir_vec):
    """
    计算一个方向向量与正北方向的夹角
    :param dir_vec: 含 x,y 2个元素的方向向量 (x,y)或(lng, lat)
    :return: 其与正北方向夹角的余弦值[-1, 1]
    """
    north_vec = (0, 1)
    dir_vec = VectorUnitize(dir_vec)  # 化为单位向量
    len_north_vec = 1
    len_dir_vec = 1
    cos_theta = (north_vec[0] * dir_vec[0] + north_vec[1] * dir_vec[1]) / (len_north_vec * len_dir_vec)
    return cos_theta


def WithinBounds(lat, lng, min_lat, max_lat, min_lng, max_lng):
    """
    该点是否在规定区域内
    :return: 是或否
    """
    if min_lat <= lat <= max_lat and min_lng <= lng <= max_lng:
        return True
    return False


def CalDist(point1, point2):
    """
    计算两位置点间欧式距离
    :param point1:
    :param point2:
    :return: 距离
    """
    return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)


def GetDataWithBound(user_id, with_t, convert, min_lat, max_lat, min_lng, max_lng):
    """
    读取Geolife 1.3数据集中特定id用户的轨迹数据（去除重复点）
    :param user_id: Geolife数据集中的用户id
    :param with_t: 读取的数据中含不含时间信息
    :param convert: 是否进行坐标转换
    :param min_lat, max_lat, min_lng, max_lng: 最小纬度，最大纬度，最小精度，最大经度，用于数据筛选
    :return: 三维列表表示的轨迹数据，第1维表示轨迹数目，第2维表示轨迹中的位置点数目，第3维表示纬度、经度和时间
    """
    lat_str = []  # 纬度
    lng_str = []  # 经度
    time_str = []  # 时间
    path = "../Geolife Trajectories 1.3" + "/Data" + "/" + user_id + "/Trajectory"
    plt_files = os.listdir(path)
    plt_files.sort()

    data = []  # 最终读取结果
    i = 0
    for item in plt_files:  # 每一个文件的绝对路径
        i += 1
        path_item = path + "/" + item
        # path_item = path + "\\" + item
        with open(path_item, 'r') as fp:
            for item in fp.readlines()[6:]:
                item_list = item.split(',')
                lat_str.append(item_list[0])
                lng_str.append(item_list[1])
                time_str.append(item_list[6])

        lat_float = [float(x) for x in lat_str]
        lng_float = [float(x) for x in lng_str]
        time_int = [ParseTime(x) for x in time_str]
        data.append(list(zip(lat_float, lng_float, time_int)))
        lat_str, lng_str, lat_float, lng_float, time_str, time_int = [], [], [], [], [], []

    print("原始数据中共有轨迹条数: ", len(data))
    data_with_bound = []
    for traj in data:
        flag = True
        for point in traj:
            if not WithinBounds(point[0], point[1], min_lat, max_lat, min_lng, max_lng):  # 有一个点不在区域内就排除该轨迹
                flag = False
                break
        if flag:  # 没有超出范围
            if not with_t:
                traj_without_t = [(point[0], point[1]) for point in traj]
                data_with_bound.append(traj_without_t)
            else:
                data_with_bound.append(traj)
    print("指定范围数据中共有轨迹条数: ", len(data_with_bound))

    # 删除重合的点，并且进行坐标转换
    delete_repeat = []
    for traj in data_with_bound:
        tmp = []
        if convert:
            x_y = CoordSysConv.CoordConvert(traj[0][0], traj[0][1], min_lat, min_lng)
        else:
            if with_t:
                x_y = [traj[0][0], traj[0][1], traj[0][2]]
            else:
                x_y = [traj[0][0], traj[0][1]]
        tmp.append(x_y)
        for i in range(1, len(traj)):
            if not (traj[i][0] == traj[i-1][0] and traj[i][1] == traj[i-1][1]):
                if convert:
                    x_y = CoordSysConv.CoordConvert(traj[i][0], traj[i][1], min_lat, min_lng)
                else:
                    if with_t:
                        x_y = [traj[i][0], traj[i][1], traj[i][2]]
                    else:
                        x_y = (traj[i][0], traj[i][1])
                tmp.append(x_y)
            else:
                pass
        if len(tmp) > 3:
            delete_repeat.append(tmp)

    return delete_repeat


def CalRegion(id, min_lat=-90, max_lat=90, min_lng=-180, max_lng=180):
    data = GetDataWithBound(id, True, False, min_lat, max_lat, min_lng, max_lng)
    max_lat = 0
    min_lat = 1000
    max_lng = 0
    min_lng = 1000
    for traj in data:
        lat_list = [point[0] for point in traj]
        lng_list = [point[1] for point in traj]
        max_lat = max(max_lat, max(lat_list))
        min_lat = min(min_lat, min(lat_list))
        max_lng = max(max_lng, max(lng_list))
        min_lng = min(min_lng, min(lng_list))
    return min_lat, max_lat, min_lng, max_lng


def CalAvgTrajLen(id, min_lat=-90., max_lat=90., min_lng=-180., max_lng=180., n=1000):
    data = GetDataWithBound(id, True, False, min_lat, max_lat, min_lng, max_lng)
    if n < len(data):
        data = data[:n]
    len_list = []
    for traj in data:
        len_list.append(len(traj))
    return sum(len_list) / len(data)
