"""
使用MN算法生成虚拟轨迹并绘制图像
"""
import random
import numpy as np


class DummyPoint:
    def __init__(self, lng=0, lat=0, t=0):
        """
        虚拟轨迹点
        :param lng: 经度
        :param lat: 纬度
        :param t:时间戳
        """
        self.lng = lng
        self.lat = lat
        self.t = t

    def WithinBounds(self, max_lng, min_lng, max_lat, min_lat):
        """
        该点是否在规定区域内
        :return: 是或否
        """
        if min_lat <= self.lat <= max_lat and min_lng <= self.lng <= max_lng:
            return True
        return False


def MovingInNeighborhood(m, n, with_t, max_lng, min_lng, max_lat, min_lat):
    """
    生成一条虚拟轨迹
    :param m: 每次移动的幅度
    :param n: 轨迹长度（轨迹点数）
    :param with_t: 是否生成时间维度
    :param max_lng, min_lng, max_lat, min_lat: 生成轨迹点的限制范围
    :return: 虚拟轨迹
    """

    dummyNexttemp = DummyPoint()  # 后一时刻用户位置及时间信息
    dummyNexttemp.lng = random.uniform(min_lng, max_lng)
    dummyNexttemp.lat = random.uniform(min_lat, max_lat)
    if with_t:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng, random.randint(0, 24 * 3600)]]  # 初始状态，轨迹列表只有初始点
    else:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng]]  # 初始状态，轨迹列表只有初始点（删除时间维度）

    i = 0
    num_errors = 50  # 有时候出界后回不去，这种状态最多卡死num_errors次，就会随机选择一个位置跳出
    dummyPretemp = dummyNexttemp  # 前一时刻用户位置及时间信息（这里初始化）
    while i < n - 1:
        # 生成下一位置及时间信息
        dummyNexttemp.lng = random.uniform(dummyPretemp.lng - m, dummyPretemp.lng + m)
        dummyNexttemp.lat = random.uniform(dummyPretemp.lat - m, dummyPretemp.lat + m)
        dummyNexttemp.t = dummyPretemp.t + random.randint(17, 22)  # 计时方法
        if dummyNexttemp.WithinBounds(max_lng, min_lng, max_lat, min_lat):  # 在规定区域内才添加到列表，否则重新生成
            dummyPretemp = dummyNexttemp
            if with_t:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng, dummyNexttemp.t])
            else:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng])  # 删除时间维度
            i = i + 1
        else:  # 如果一直发生越界错误就随机找一个点（该情况存在但极少）
            if num_errors > 0:
                num_errors -= 1
            else:
                lng = random.uniform(min_lng, max_lng)
                lat = random.uniform(min_lat, max_lat)
                if with_t:
                    dummy.append([lat, lng, dummyNexttemp.t])
                else:
                    dummy.append([lat, lng])  # 删除时间维度
                num_errors = 50
    return dummy
