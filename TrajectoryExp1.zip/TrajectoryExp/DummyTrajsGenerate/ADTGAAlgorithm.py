import math
import pickle
import random
import numpy as np

from Utiliy import Utils
from Utiliy.Utils import CalDist, VectorUnitize, GetDataWithBound

# 纬度范围
minLat = 39.85
maxLat = 40.05
# 经度范围
minLng = 116.2
maxLng = 116.5


def Rotate(point, rotate_angle, rotate_point):
    """
    以特定角度，特点中心点选择某个点
    :param point: 待旋转的点
    :param rotate_angle: 旋转角度
    :param rotate_point: 旋转中心点
    :return: 旋转后的点
    """
    x, y, t = point
    x0, y0 = rotate_point[0:2]
    theta = rotate_angle
    x_ = (x - x0) * math.cos(theta) - (y - y0) * math.sin(theta) + x0
    y_ = (x - x0) * math.sin(theta) + (y - y0) * math.cos(theta) + y0
    return x_, y_, t


def GenerateDummy(real_trajectory, rotate_angle, rotate_point, with_t):
    """
    通过旋转生成一条虚拟轨迹
    :param real_trajectory: 真实轨迹
    :param rotate_angle: 旋转角度 ∈ (0,2π)
    :param rotate_point: 旋转点
    :return: 虚拟轨迹
    """
    points = real_trajectory
    dummy_trajectory = [Rotate(point, rotate_angle, rotate_point) for point in points]
    if not with_t:
        dummy_trajectory = [item[0:2] for item in dummy_trajectory]
    return dummy_trajectory


def CalTDDForAll(trajectories, num_stamp):
    """
    对当前轨迹计算TDD (Trajectories Distance Deviation, 轨迹距离偏差)
    :param trajectories: 当前所有轨迹的数组
    :param num_stamp: 每条轨迹中的时间戳数量（位置点数量）
    :return: TDD计算结果
    """
    n = len(trajectories)  # number of trajectories
    sum = 0
    for i in range(0, n - 1):  # 所有轨迹（包括真实轨迹）
        for k in range(i + 1, n):  # 所有与i轨迹计算距离的轨迹
            for j in range(0, num_stamp):  # 所有时刻
                sum = sum + CalDist(trajectories[i][j][:2], trajectories[k][j][:2])
    tdd = sum * (1 / num_stamp) * (2 / n * (n - 1))
    return tdd


def SatisfyTDDMetric(real_trajectory, dummys, new_dummy, TDDMetric):
    """
    判断当前虚拟轨迹加入集合后是否满足TDD指标要求
    :param real_trajectory: 真实轨迹
    :param dummys: 虚拟轨迹集合
    :param new_dummy: 新生成的虚拟轨迹
    :param tdd_metric: TDD指标
    :return: 当前轨迹是否满足TDD指标要求
    """
    trajectories = [real_trajectory] + dummys + [new_dummy]
    trajectories = [[point[0:2] for point in traj] for traj in trajectories]
    num_stamp = len(real_trajectory)
    new_tdd = CalTDDForAll(trajectories, num_stamp)
    # print("tdd: ", new_tdd)
    if new_tdd > TDDMetric:
        return True
    else:
        return False


def CalTSD(real_trajectory, dummys, delta_t=4, threshold=1e-6):
    """
    对当前轨迹集合计算TSD (短期隐私暴露，delta-t short term disclosure)
    :param real_trajectory: 真实轨迹
    :param dummys: 虚假轨迹列表
    :param delta_t: TSD的参数，衡量短期具体有多久
    :param threshold: TSD阈值
    :return: TSD值
    """
    num_stamps = len(real_trajectory)
    end = num_stamps // delta_t * delta_t
    trajs = [real_trajectory] + dummys
    new_trajs = []
    for traj in trajs:
        new_traj = []
        for point in traj:
            new_traj.append((point[0], point[1]))
        new_trajs.append(new_traj)
    trajs = new_trajs
    sum_p = 0
    for i in range(0, end, delta_t):  # 能整除的轨迹段
        set_without_repeat = []
        num_repeat_times = []
        for j in range(delta_t):
            for k in range(len(trajs)):
                point = trajs[k][i+j]
                is_repeat = False
                for n in range(len(set_without_repeat)):
                    other_point = set_without_repeat[n]
                    if CalDist(point, other_point) < threshold:  # 原本应该判等，但因为数据精度较高，只需要两点距离很近即算作位置暴露
                       is_repeat = True
                       num_repeat_times[n] += 1
                       break
                if not is_repeat:
                    set_without_repeat.append(point)
                    num_repeat_times.append(0)
        sum_p += delta_t / len(set_without_repeat)

    # 余下的轨迹段
    if num_stamps != end:
        set_without_repeat = []
        num_repeat_times = []
        for i in range(end, num_stamps):
            for k in range(len(trajs)):
                point = trajs[k][i]
                is_repeat = False
                for n in range(len(set_without_repeat)):
                    other_point = set_without_repeat[n]
                    if CalDist(point, other_point) < threshold:  # 原本应该判等，但因为数据精度较高，只需要两点距离很近即算作位置暴露
                        is_repeat = True
                        num_repeat_times[n] += 1
                        break
                if not is_repeat:
                    set_without_repeat.append(point)
                    num_repeat_times.append(0)
        sum_p += (num_stamps - end) / len(set_without_repeat)
    sum_p = sum_p / (num_stamps // delta_t)

    return sum_p


adj_matrix = []  # CountPaths中使用
def CountPaths(start_node):
    global adj_matrix
    visited = [False] * len(adj_matrix)
    stack = [start_node]
    count = 0
    while stack:
        node = stack.pop()
        visited[node] = True
        has_neighbor = False
        for neighbor in range(len(adj_matrix[node])):
            if adj_matrix[node][neighbor] == 1:
                has_neighbor = True
                if not visited[neighbor]:
                    stack.append(neighbor)
        if not has_neighbor:
            count += 1
    return count


def CalLD(real_traj, dummys, threshold=1e-5):
    """
    计算当前轨迹集合的LD (长期隐私暴露，long term disclosure)
    :param real_traj: 真实轨迹
    :param dummys: 虚拟轨迹列表
    :param threshold: 认为位置相同的距离阈值
    :param threshold: 算法中原本需要对轨迹点判等，由于计算精度较高，允许其之间有一定距离而非距离为0
    :return:
    """
    len_traj = len(real_traj)
    trajs = [real_traj] + dummys

    new_trajs = []
    for traj in trajs:
        new_traj = []
        for point in traj:
            new_traj.append((point[0], point[1]))
        new_trajs.append(new_traj)
    trajs = new_trajs


    point_list = []  # 没有重复的点的列表
    id_list = [[-1 for j in range(len_traj)] for i in range(len(trajs))]

    id = 0

    for i in range(len(trajs)):
        for j in range(len_traj):
            point1 = trajs[i][j]
            flag = False  # 不重复
            for k in range(len(point_list)):
                point2 = point_list[k]
                if Utils.CalDist(point1, point2[0]) < threshold:  # 认为两点重复
                    flag = True
                    id_list[i][j] = id_list[point_list[k][1]][point_list[k][2]]
                    break
            if not flag:
                point_list.append((point1, i, j))
                id_list[i][j] = id
                id += 1
    num_nodes = len(point_list)
    global adj_matrix
    adj_matrix = [[0 for i in range(num_nodes)] for j in range(num_nodes)]
    for i in range(len(trajs)):
        for j in range(1, len_traj):
            adj_matrix[id_list[i][j-1]][id_list[i][j]] = 1

    result = 0
    for i in range(len(trajs)):
        result += CountPaths(i)

    return 1 / (result + 1e-6)


def Perturbation(dummys, dummy, k, center):
    """
    对当前虚拟轨迹进行扰动， 计算现有其他虚拟轨迹坐标点的平均值，其相对于中心有一定偏差，
    向该偏差反方向移动当前考虑的虚拟轨迹
    :param dummys: 虚拟轨迹列表
    :param dummy: 当前在处理的虚拟轨迹
    :param k: 扰动程度
    :param center: 所考虑区域的中心点坐标
    :return: 扰动后的虚拟轨迹
    """
    if dummys:
        avg_x = np.mean([np.mean([point[1] for point in traj]) for traj in dummys])
        avg_y = np.mean([np.mean([point[0] for point in traj]) for traj in dummys])
        vec_x = avg_x - center[1]
        vec_y = avg_y - center[0]
        vec_x, vec_y = VectorUnitize([vec_x, vec_y])
    else:
        vec_x = 0
        vec_y = 0

    result = []
    with_t = True if len(dummy[0]) == 3 else False
    for point in dummy:
        new_point = [point[0], point[1]]
        if with_t:
            new_point.append(point[2])
        if random.random() < k:
            # print(new_point)
            new_point[0] += -1. / 1000 * random.randint(1, 10) * (maxLat - minLat) * vec_x
            new_point[1] += -1. / 1000 * random.randint(1, 10) * (maxLng - minLng) * vec_y
            # print(new_point)
            # print("==============")
            if with_t:
                new_point[2] = point[2]
        result.append(new_point)
    return result


def ADTGAAlgorithm(real_trajectory, k_metric, tsd_metric, tdd_metric, ld_metric):
    """
    :param real_trajectory: 真实轨迹数据[(lat, lng, t), (lat, lng, t), ...]
    :param k_metric: 扰动程度
    :param tsd_metric: TSD指标 (Δt-Short term Disclosure)
    :param tdd_metric: TDD指标 (Trajectories Distance Deviation)
    :param ld_metric: LD指标 (Long term Disclosure)
    """
    dummys = []
    while True:
        candidate = []
        angles = [item * 1 / 18 * math.pi for item in list(range(3, 33, 3))]  # [10°, 20°, ... , 350°]
        for angle in angles:
            for i in range(0, len(real_trajectory), 50):
                rotate_point = real_trajectory[i]
                dummy = GenerateDummy(real_trajectory, angle, rotate_point, with_t=True)  # 旋转生成轨迹
                if not SatisfyTDDMetric(real_trajectory, dummys, dummy, tdd_metric):  # 不满足指标
                    continue
                dummy = Perturbation(dummys, dummy, k_metric, (minLat, minLng))
                candidate.append(dummy)
        if len(candidate) != 0:
            metric_of_candidate = []
            for dummy in candidate:
                tsd = CalTSD(real_trajectory, dummys + [dummy])
                ld = CalLD(real_trajectory, dummys + [dummy])
                metric_of_candidate.append((tsd, ld))
            # print("metric_of_candidate", metric_of_candidate)
            metric_sum = [item[0] + item[1] for item in metric_of_candidate]
            candidate_id = metric_sum.index(min(metric_sum))
            dummys.append(candidate[candidate_id])
            if metric_of_candidate[candidate_id][0] < tsd_metric and metric_of_candidate[candidate_id][1] < ld_metric:
                break
        else:
            return []
    return dummys


def GetDataByADTGA(mode, id, k_metric=0.1, tsd_metric=0.4, tdd_metric=0.003, ld_metric=0.3):
    """
    对ADTGAAlgorithm再进行封装，输入一系列真实轨迹，使其对某些真实轨迹中的部分片段生成若干条虚假轨迹，
    为了正负样本数目的平衡，我们后面需要加一些真实轨迹样本（因此这里只使用一部分真实轨迹进行生成）
    此外还可以对其进行预处理
    :param id: Geolife中的特定用户，需要读取他的轨迹数据
    :param k_metric, tsd_metric, tdd_metric, ld_metric: ADTGA算法的参数
    :return: (real_trajs, dummy_trajs)
    """
    train_set = 201
    test_set = 40

    real_data = GetDataWithBound(id, True, False, minLat, maxLat, minLng, maxLng)
    if mode == "train":
        real_data = real_data[:train_set]
        real_data_part = real_data[:train_set]  # 取部分数据
    if mode == "test":
        real_data_part = real_data[len(real_data) - test_set:]

    dummys_list = []
    real_list = []
    traj_len = 100

    for i in range(len(real_data_part)):
        num_points = len(real_data_part[i])
        if num_points > traj_len:
            start = random.randint(0, num_points - traj_len)
        else:
            start = 0
        traj = real_data_part[i][start:start + traj_len]
        print("第{}条轨迹".format(i))
        dummys = ADTGAAlgorithm(traj, k_metric, tsd_metric, tdd_metric, ld_metric)
        if mode == "train":
            if len(dummys) != 0:
                real_list.append(traj)
                dummys_list += [random.choice(dummys)]
        else:
            if len(dummys) != 0:
                dummys_list += [random.choice(dummys)]
                real_list.append(traj)

    # 通过写入二进制模式打开文件
    if mode == "train":
        pickle_file = open('ADTGA_Data_train.pkl', 'wb')
    elif mode == "test":
        pickle_file = open('ADTGA_Data_test.pkl', 'wb')
    # 序列化对象，将对象obj保存到文件file中去
    pickle.dump((real_list, dummys_list), pickle_file)
    # 关闭文件
    pickle_file.close()

    return real_list, dummys_list
