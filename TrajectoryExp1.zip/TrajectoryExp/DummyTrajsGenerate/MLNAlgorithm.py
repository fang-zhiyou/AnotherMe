"""
使用MLN算法生成虚拟轨迹并绘制图像
"""
import random
from Utiliy import TSHNUtils, Utils


class DummyPoint:
    def __init__(self, lng=0, lat=0, t=0):
        """
        虚拟轨迹点
        :param lng: 经度
        :param lat: 纬度
        :param t:时间戳
        """
        self.lng = lng
        self.lat = lat
        self.t = t

    def WithinBounds(self, max_lng, min_lng, max_lat, min_lat):
        """
        该点是否在规定区域内
        :return: 是或否
        """
        if min_lat <= self.lat <= max_lat and min_lng <= self.lng <= max_lng:
            return True
        return False


def Position(neighborhood_size, dummy_lat, dummy_lng, others_locations):
    """
    计算虚拟轨迹点邻域内真实轨迹点个数（函数名是论文中给出的，不是很容易理解）
    :param neighborhood_size: 邻域“半径”（正方形）
    :param dummy_lat: 虚拟轨迹点的纬度
    :param dummy_lng: 虚拟轨迹点的经度
    :param others_locations: 其他用户的轨迹点列表（含t）,这里直接传入真实轨迹列表
    :return: (dummyX, dummyY)的半径为neighborhood_size的邻域内存在的真实轨迹点个数
    """
    sum = 0
    for each_list in others_locations:
        for j in range(len(each_list)):
            (lat, lng) = each_list[j][:2]  # 遍历每一个真实位置
            # if random.random() > 0.15:
            #     continue
            if dummy_lat - neighborhood_size < lat < dummy_lat + neighborhood_size and dummy_lng - neighborhood_size < lng < dummy_lng + neighborhood_size:  # 如果其在虚拟位置邻域
                sum = sum + 1
    return sum


def GetOtherLocations(id, max_lng, min_lng, max_lat, min_lat, with_t=True, convert=False):
    """
    获取真实轨迹点数据
    :param id: 用户id，如"000"
    :return: 该id用户的多条真实轨迹
    """
    real_data = Utils.GetDataWithBound(id, with_t, convert, min_lat, max_lat, min_lng, max_lng)
    real_data = random.choices(real_data, k=50)
    return real_data


def MovingInNeighborhood(aveP, m, n, otherLocations, with_t, max_lng, min_lng, max_lat, min_lat):
    """
    生成一条虚拟轨迹
    :param aveP: 虚拟轨迹点邻域内最多允许存在的轨迹点个数
    :param m: 每次移动的幅度
    :param n: 轨迹长度（轨迹点个数）
    :return: 虚拟轨迹
    """
    repeatCount = 50  # 寻找稀疏位置的最多尝试次数
    # 起始点
    dummyNexttemp = DummyPoint()  # 后一时刻用户位置及时间信息
    dummyNexttemp.lng = random.uniform(min_lng, max_lng)
    dummyNexttemp.lat = random.uniform(min_lat, max_lat)
    if with_t:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng, random.randint(0, 24 * 3600)]]  # 初始状态，轨迹列表只有初始点
    else:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng]]  # 初始状态，轨迹列表只有初始点(删除时间维度)

    i = 0
    num_errors = 50  # 有时候出界后回不去，这种状态最多卡死num_errors次，就会随机选择一个位置跳出
    dummyPretemp = dummyNexttemp  # 前一时刻用户位置及时间信息
    while i < n-1:
        # 生成下一位置及时间信息
        dummyNexttemp.lng = random.uniform(dummyPretemp.lng - m, dummyPretemp.lng + m)
        dummyNexttemp.lat = random.uniform(dummyPretemp.lat - m, dummyPretemp.lat + m)
        dummyNexttemp.t = dummyPretemp.t + random.randint(17, 22)  # 计时方法
        if dummyNexttemp.WithinBounds(max_lng, min_lng, max_lat, min_lat):  # 在规定区域内才添加到列表，否则重新生成
            dummyPretemp = dummyNexttemp
            if Position(neighborhood_size=0.00001, dummy_lat=dummyNexttemp.lat, dummy_lng=dummyNexttemp.lng, others_locations=otherLocations) > aveP:  # 在稀疏区域才能添加到列表，但存在最大尝试次数
                if repeatCount > 0:
                    repeatCount = repeatCount - 1
                    continue
                else:
                    repeatCount = 5
            if with_t:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng, dummyNexttemp.t])
            else:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng])  # 删除时间维度
            i = i + 1
        else:  # 如果一直发生越界错误就随机找一个点（该情况存在但极少）
            if num_errors > 0:
                num_errors -= 1
            else:
                lng = random.uniform(min_lng, max_lng)
                lat = random.uniform(min_lat, max_lat)
                dummyPretemp.lng = lng
                dummyPretemp.lat = lat
                dummyPretemp.t = dummyNexttemp.t
                if with_t:
                    dummy.append([lat, lng, dummyNexttemp.t])
                else:
                    dummy.append([lat, lng])  # 删除时间维度
                num_errors = 50
    return dummy

