import math
import random
from Utiliy.Utils import CalDist

# 纬度范围
minLat = 39.85
maxLat = 40.05
# 经度范围
minLng = 116.2
maxLng = 116.5
id = "003"


def RcDL(lat_t, lng_t, K, R):
    dummy_point_set = []
    for i in range(K):
        dummy_point_lat = random.uniform(lat_t - R, lat_t + R)
        dummy_point_lng = random.uniform(lng_t - R, lng_t + R)
        dist = CalDist([lat_t, lng_t], [dummy_point_lat, dummy_point_lng])
        if dist < R:
            dummy_point_set.append([dummy_point_lat, dummy_point_lng])
        else:
            q = random.randint(1, 8)
            if q <= 2:
                dummy_point_lat = lat_t - math.sqrt(R**2 - (lng_t - dummy_point_lng)**2)
            elif q <= 4:
                dummy_point_lat = lat_t + math.sqrt(R**2 - (lng_t - dummy_point_lng)**2)
            elif q <= 6:
                dummy_point_lng = lng_t - math.sqrt(R**2 - (lat_t - dummy_point_lat)**2)
            else:
                dummy_point_lng = lng_t + math.sqrt(R**2 - (lat_t - dummy_point_lat)**2)
            # 更新点并加入集合
            dummy_point_set.append([dummy_point_lat, dummy_point_lng])
    return dummy_point_set


def CalSIM(real_traj, dummy_traj, delta=1):
    assert len(real_traj) == len(dummy_traj)
    total_sim = 0
    for i in range(len(real_traj)):
        total_sim += (abs(real_traj[i][0] - dummy_traj[i][0]) + abs(real_traj[i][1] - dummy_traj[i][1])) / delta
    sim = total_sim / len(real_traj)
    return sim


def IsSame(point0, point1, threshold=0.000001):
    if CalDist(point0, point1) < threshold:
        return True
    else:
        return False


def CalSE(traj, traj_set_temp):
    traj_len = len(traj)
    se = 0
    for t in range(traj_len):
        sum = 1
        point_set_t = [traj[t]] + [traj[t] for traj in traj_set_temp]
        exist_point = [point_set_t[0]]
        for point in point_set_t[1:]:
            for compare_point in exist_point:
                if not IsSame(point, compare_point):
                    sum += 1
        se += ((1 / traj_len) * (1 / sum))
    return se


def RcDT(traj, K, R, SIM, SE, TE, with_t=False):
    # 生成虚假起点
    if with_t:
        lat_1, lng_1, t_1 = traj[0]
    else:
        lat_1, lng_1 = traj[0]
    start_set = RcDL(lat_1, lng_1, K, R)
    # 将起点集合变为轨迹集合
    dummy_traj_set = [[start_point] for start_point in start_set]
    # 生成后面的虚假位置点，形成虚拟轨迹
    num_points = len(traj)
    for t in range(1, num_points):  # 起始t为0，后续从1开始
        traj_set_temp = []
        if with_t:
            lat_t, lng_t, t_t = traj[t]
        else:
            lat_t, lng_t = traj[t]
        dummy_point_set_t = RcDL(lat_t, lng_t, K, R)
        for dummy_traj in dummy_traj_set:  # 在虚假轨迹集合中选一个
            flag = 0  # 没有给该轨迹添加新位置点
            for point in dummy_point_set_t:  # 在t时刻的虚拟位置点集中选一个
                dummy_traj_temp = dummy_traj + [point]  # 尝试把该点续在轨迹后
                sim = CalSIM(traj[:t+1], dummy_traj_temp)
                if sim <= SIM:
                    flag = 1
                    traj_set_temp.append(dummy_traj_temp)  # update
                    break
            if not flag:  # 随便选一个点添加
                random_point = random.choice(dummy_point_set_t)
                dummy_traj_temp = dummy_traj + [random_point]  # 尝试把该点续在轨迹后
                traj_set_temp.append(dummy_traj_temp)  # update
        se_t = CalSE(traj[:t+1], traj_set_temp)
        if se_t < SE:
            dummy_traj_set = traj_set_temp
        else:
            t -= 1
            continue
    if with_t:
        dummy_traj_list = [[] for i in range(K)]
        for traj_index in range(len(dummy_traj_set)):
            for i in range(len(traj)):
                t = traj[i][2]
                dummy_traj_list[traj_index].append([dummy_traj_set[traj_index][i][0], dummy_traj_set[traj_index][i][1], t])
    else:
        dummy_traj_list = dummy_traj_set
    return dummy_traj_list
